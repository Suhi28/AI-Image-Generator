package com.SpringAI.ai;


import org.springframework.ai.image.ImagePrompt;
import org.springframework.ai.image.ImageResponse;
import org.springframework.ai.openai.OpenAiImageModel;
import org.springframework.ai.openai.OpenAiImageOptions;
import org.springframework.stereotype.Service;

@Service
public class ImageService {
    private final OpenAiImageModel openAiImageModel;

    public ImageService(OpenAiImageModel openAiImageModel) {
        this.openAiImageModel = openAiImageModel;
    }

    public ImageResponse generateImage(String prompt, String quality, int n, int width, int height)
    {
        try {
            return openAiImageModel.call(
                    new ImagePrompt(prompt,
                            OpenAiImageOptions.builder()
                                    .withModel("dall-e-2")
                                    .withQuality(quality)
                                    .withN(n)
                                    .withHeight(height)
                                    .withWidth(width)
                                    .build())
            );
        }catch (Exception e){
            throw new RuntimeException("Image generation failed: " + e.getMessage());
        }
    }
}
