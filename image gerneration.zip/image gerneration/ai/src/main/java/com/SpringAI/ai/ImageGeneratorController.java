package com.SpringAI.ai;

import org.springframework.ai.image.ImageResponse;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api")
public class ImageGeneratorController {

    private final ImageService imageService;

    public ImageGeneratorController(ImageService imageService) {
        this.imageService = imageService;
    }
    @PostMapping("/generateImage")
    public List<String> generateImage(@RequestBody Map<String, Object> request) throws IOException{
        String prompt = (String) request.get("prompt");
        String quality = (String) request.getOrDefault("quality", "hd");
        int n = (int) request.getOrDefault("n", 3);
        int width = (int) request.getOrDefault("width", 512);
        int height = (int) request.getOrDefault("height", 512);

    try    {
        ImageResponse imageResponse = imageService.generateImage(prompt, quality, n, width, height);
        return imageResponse.getResults()
                .stream()
                .map(result -> result.getOutput().getUrl())
                .toList();
        }catch (Exception e){
        throw new IOException("Error generating image: " + e.getMessage());
         }
    }
}
